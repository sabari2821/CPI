import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {

        // Get the error from the property
        def exception = message.getProperty("CamelExceptionCaught");

        if (exception != null) {
            def errorMessage = exception.getMessage();
            messageLog.addCustomHeaderProperty("Error Message", errorMessage);
        }
    }

    return message;
}
